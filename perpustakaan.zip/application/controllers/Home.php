<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {

	public function index()
	{
        if ($this->session->userdata('level') == 'Administrator') {
            redirect('admin/dashboard');
        } elseif ($this->session->userdata('level') == 'Karyawan') {
            redirect('admin/dashboard');
        } else {
            $digit1 = mt_rand(1, 20);
            $digit2 = mt_rand(1, 20);
            
            $captcha = array('captcha' => $digit1+$digit2);

            $this->session->set_userdata($captcha);
            $data['captcha'] = "$digit1 + $digit2 = ?";
            $data['pengaturan'] = $this->m_model->get_desc('tb_pengaturan');

            $this->load->view('login', $data);
        }
    }
    
    public function auth()
    {
        $username = $_POST['username'];
        $password = $_POST['password'];
        $jawaban  = $_POST['jawaban'];

        $where = array(
            'username' => $username,
            'password' => md5($password)
        );

        if(!empty($jawaban)) {
            if($jawaban == $this->session->userdata('captcha')) {
                $cek = $this->m_model->get_where($where, 'tb_user');
    
                if ($cek->num_rows() > 0) {
                    foreach ($cek->result_array() as $row) {
                        $data = array(
                            'id'        => $row['id'],
                            'nama'      => $row['nama'],
                            'username'  => $row['username'],
                            'level'     => $row['level'],
                            'skin'      => $row['skin'],
                        );
    
                        $this->session->set_userdata($data);
                        if($row['level'] == 'Administrator'){
                            redirect('admin/dashboard');
                        } elseif($row['level'] == 'Karyawan'){
                            redirect('admin/dashboard');
                        }
                    }
                } else {
                    $this->session->set_flashdata('pesan', 'Username atau Password anda salah!');
                    redirect('home');
                }
            } else {
                $this->session->set_flashdata('pesan', 'Hitung dengan benar!');
                redirect('home');
            }
        } else {
            $this->session->set_flashdata('pesan', 'Captcha harap diisi!');
            redirect('home');
        }
    }

    public function logout()
    {
        $this->session->sess_destroy();
        redirect('home');
    }
}
