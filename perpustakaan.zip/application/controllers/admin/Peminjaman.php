<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Peminjaman extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if(!$this->session->userdata('level')){
			$this->session->set_flashdata('pesan', 'Anda harus masuk terlebih dahulu!');
			redirect('home');
		}
	}

	public function index()
	{
        $data['title']  = 'Data Peminjaman';
        $data['peminjaman'] = $this->m_model->get_desc('tb_peminjaman');
		
		$this->load->view('admin/templates/header', $data);
		$this->load->view('admin/templates/sidebar');
		$this->load->view('admin/peminjaman');
		$this->load->view('admin/templates/footer');
    }
    
    public function add()
	{
        $data['title']      = 'Tambah Data Peminjaman';
        $data['anggota']    = $this->m_model->get_desc('tb_anggota');
        $data['buku']       = $this->m_model->get_desc('tb_buku');
		
		$this->load->view('admin/templates/header', $data);
		$this->load->view('admin/templates/sidebar');
		$this->load->view('admin/addpeminjaman');
		$this->load->view('admin/templates/footer');
    }
    
    public function insert()
    {
        $idAnggota  = $_POST['idAnggota'];
        $idBuku     = $_POST['idBuku'];
        $jml        = $_POST['jml'];
        $tglPinjam  = $_POST['tglPinjam'];
        $tglKembali = $_POST['tglKembali'];

        $data = array(
            'idAnggota'     => $idAnggota,
            'idBuku'        => $idBuku,
            'jml'           => $jml,
            'tglPinjam'     => $tglPinjam,
            'tglKembali'    => $tglKembali
        );

        $where = array('id' => $idBuku, );
        $cek = $this->m_model->get_where($where, 'tb_buku');
        foreach ($cek->result() as $cStk) {
            $stokNow = $cStk->stok - $jml;
            $stokBuku = array('stok' => $stokNow);
        }
        $this->m_model->update($where, $stokBuku, 'tb_buku');
        $this->m_model->insert($data, 'tb_peminjaman');
        $this->session->set_flashdata('pesan', 'Peminjaman berhasil ditambahkan!');
        redirect('admin/peminjaman');
    }

    public function perpanjang($id, $tglKembali)
    {
        $where = array('id' => $id);
        $data = array('tglKembali' => date('Y-m-d', strtotime('+7 Days', strtotime($tglKembali))));

        $this->m_model->update($where, $data, 'tb_peminjaman');
        $this->session->set_flashdata('pesan', 'Peminjaman berhasil diperpanjang!');
        redirect('admin/peminjaman');
    }

    public function kembali($id)
    {
        date_default_timezone_set('Asia/Jakarta');
        $where = array('id' => $id);

        $dataPeminjaman = $this->m_model->get_where($where, 'tb_peminjaman');
        foreach ($dataPeminjaman->result_array() as $dtPjm) {
            $this->db->where('id', $dtPjm['idBuku']);
            $dataBuku = $this->db->get('tb_buku');
            foreach ($dataBuku->result_array() as $dtBk) {
               $newStok = $dtBk['stok'] + $dtPjm['jml'];
               $whereUpdateBuku = array('id' => $dtPjm['idBuku']);
               $updateBuku = array('stok' => $newStok);
               $this->m_model->update($whereUpdateBuku, $updateBuku, 'tb_buku');
            }
        }

        $tglPengembalian = date('Y-m-d');

        if (date('Y-m-d') > $dtPjm['tglKembali']) {
            $now = date('Y-m-d');
            $tgl = $dtPjm['tglKembali'];
            $hari = abs((strtotime($now) - strtotime($tgl)) / (60*60*24));
            $denda = $this->db->query('SELECT denda FROM tb_pengaturan');
            foreach ($denda->result() as $dnd) {}
            $updateDenda = $hari * $dnd->denda;
        } else {
            $updateDenda = 0;
        }

        $data = array(
            'tglPengembalian'   => $tglPengembalian,
            'denda'             => $updateDenda
        );
        $this->m_model->update($where, $data, 'tb_peminjaman');
        $this->session->set_flashdata('pesan', 'Buku berhasil dikembalikan!');
        redirect('admin/peminjaman');
    }

    public function exportbelumkembali()
    {
        $where = array('tglPengembalian' => '0000-00-00');
        $this->db->ORDER_BY('id', 'DESC');
        $data['peminjaman'] = $this->m_model->get_where($where, 'tb_peminjaman');

        $this->load->view('admin/exportbelumkembali', $data);
    }

    public function cetakbelumkembali()
    {
        $where = array('tglPengembalian' => '0000-00-00');
        $this->db->ORDER_BY('id', 'DESC');
        $data['peminjaman'] = $this->m_model->get_where($where, 'tb_peminjaman');

        $this->load->view('admin/cetakbelumkembali', $data);
    }
}
