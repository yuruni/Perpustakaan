<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Rak extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if(!$this->session->userdata('level')){
			$this->session->set_flashdata('pesan', 'Anda harus masuk terlebih dahulu!');
			redirect('home');
		}
	}

	public function index()
	{
        $data['title']  = 'Data Rak';
        $data['rak']    = $this->m_model->get_desc('tb_rak');
		
		$this->load->view('admin/templates/header', $data);
		$this->load->view('admin/templates/sidebar');
		$this->load->view('admin/rak');
		$this->load->view('admin/templates/footer');
    }
    
    public function insert()
    {
        $rak       = $_POST['rak'];

        $data = array(
            'rak' => $rak
        );

        $this->m_model->insert($data, 'tb_rak');
        $this->session->set_flashdata('pesan', 'Rak buku berhasil ditambahkan!');
        redirect('admin/rak');
    }

    public function delete($id)
    {
        $where = array('id' => $id);

        $this->m_model->delete($where, 'tb_rak');
        $this->session->set_flashdata('pesan', 'Rak buku berhasil dihapus!');
        redirect('admin/rak');
    }

    public function update($id)
    {
        $rak       = $_POST['rak'];

        $data = array(
            'rak' => $rak
        );

        $where = array('id' => $id);

        $this->m_model->update($where, $data, 'tb_rak');
        $this->session->set_flashdata('pesan', 'Rak buku berhasil diubah!');
        redirect('admin/rak');
    }
}
