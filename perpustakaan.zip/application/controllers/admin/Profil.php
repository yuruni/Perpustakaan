<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profil extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if(!$this->session->userdata('level')){
			$this->session->set_flashdata('pesan', 'Anda harus masuk terlebih dahulu!');
			redirect('home');
		}
	}

	public function index()
	{
        $data['title'] = 'Profil';
		
		$this->load->view('admin/templates/header', $data);
		$this->load->view('admin/templates/sidebar');
		$this->load->view('admin/profil');
		$this->load->view('admin/templates/footer');
    }
    
    public function update($id)
    {
        $nama       = $_POST['nama'];
        $username   = $_POST['username'];
        $skin       = $_POST['skin'];
        $password   = $_POST['password'];

        $where = array('id' => $id);

        if($password != ''){
            $data = array(
                'nama'      => $nama,
                'username'  => $username,
                'skin'      => $skin,
                'password'  => md5($password),
            );
        } else {
            $data = array(
                'nama'      => $nama,
                'username'  => $username,
                'skin'      => $skin
            );
        }

        $this->session->set_userdata($data);
        $this->m_model->update($where, $data, 'tb_user');
        $this->session->set_flashdata('pesan', 'Profil berhasil diubah!');
        redirect('admin/profil');
    }
}
