<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Anggota extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if(!$this->session->userdata('level')){
			$this->session->set_flashdata('pesan', 'Anda harus masuk terlebih dahulu!');
			redirect('home');
		}
	}

	public function index()
	{
        $data['title'] = 'Data Anggota';
        $data['anggota'] = $this->m_model->get_desc('tb_anggota');
		
		$this->load->view('admin/templates/header', $data);
		$this->load->view('admin/templates/sidebar');
		$this->load->view('admin/anggota');
		$this->load->view('admin/templates/footer');
    }
    
    public function insert()
    {
        date_default_timezone_set('Asia/Jakarta');
        $nama           = $_POST['nama'];
        $jenisKelamin   = $_POST['jenisKelamin'];
        $tempatLahir    = $_POST['tempatLahir'];
        $tanggalLahir   = $_POST['tanggalLahir'];
        $telp           = $_POST['telp'];
        $alamat         = $_POST['alamat'];
        $noAnggota      = $_POST['no'];

        $data = array(
            'no'            => $noAnggota,
            'nama'          => $nama,
            'jenisKelamin'  => $jenisKelamin,
            'tempatLahir'   => $tempatLahir,
            'tanggalLahir'  => $tanggalLahir,
            'telp'          => $telp,
            'alamat'        => $alamat
        );

        $where = array('no' => $noAnggota);
        $cek = $this->m_model->get_where($where, 'tb_anggota');
        if(empty($cek->num_rows())) {    
            $this->m_model->insert($data, 'tb_anggota');
            $this->session->set_flashdata('pesan', 'Anggota baru berhasil ditambahkan!');
            redirect('admin/anggota');
        } else {
            $this->session->set_flashdata('pesanError', 'Kode anggota sudah ada!');
            redirect('admin/anggota');
        }
    }

    public function delete($id)
    {
        $where = array('id' => $id);

        $this->m_model->delete($where, 'tb_anggota');
        $this->session->set_flashdata('pesan', 'Anggota berhasil dihapus!');
        redirect('admin/anggota');
    }

    public function update($id)
    {
        $nama           = $_POST['nama'];
        $jenisKelamin   = $_POST['jenisKelamin'];
        $tempatLahir    = $_POST['tempatLahir'];
        $tanggalLahir   = $_POST['tanggalLahir'];
        $telp           = $_POST['telp'];
        $alamat         = $_POST['alamat'];

        $where = array('id' => $id);

        $data = array(
            'nama'          => $nama,
            'jenisKelamin'  => $jenisKelamin,
            'tempatLahir'   => $tempatLahir,
            'tanggalLahir'  => $tanggalLahir,
            'telp'          => $telp,
            'alamat'        => $alamat
        );

        $this->m_model->update($where, $data, 'tb_anggota');
        $this->session->set_flashdata('pesan', 'Anggota berhasil diubah!');
        redirect('admin/anggota');
    }

    public function exportsemua()
    {
        $data['anggota'] = $this->m_model->get_desc('tb_anggota');

        $this->load->view('admin/exportanggota', $data);
    }

    public function cetaksemua()
    {
        $data['anggota'] = $this->m_model->get_desc('tb_anggota');

        $this->load->view('admin/cetakanggota', $data);
    }
}
