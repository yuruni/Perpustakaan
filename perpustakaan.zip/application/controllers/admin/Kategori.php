<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kategori extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if(!$this->session->userdata('level')){
			$this->session->set_flashdata('pesan', 'Anda harus masuk terlebih dahulu!');
			redirect('home');
		}
	}

	public function index()
	{
        $data['title'] = 'Data Kategori';
        $data['kategori'] = $this->m_model->get_desc('tb_kategori');
		
		$this->load->view('admin/templates/header', $data);
		$this->load->view('admin/templates/sidebar');
		$this->load->view('admin/kategori');
		$this->load->view('admin/templates/footer');
    }
    
    public function insert()
    {
        $kode       = $_POST['kode'];
        $kategori   = $_POST['kategori'];

        $where = array('kode' => $kode);
        $cek = $this->m_model->get_where($where, 'tb_kategori');
        if(empty($cek->num_rows())) {
            $data = array(
                'kode' => $kode,
                'kategori' => $kategori
            );
    
            $this->m_model->insert($data, 'tb_kategori');
            $this->session->set_flashdata('pesan', 'Kategori berhasil ditambahkan!');
            redirect('admin/kategori');
        } else {
            $this->session->set_flashdata('pesanError', 'Kategori sudah ada!');
            redirect('admin/kategori');
        }
    }

    public function delete($id)
    {
        $where = array('id' => $id);

        $this->m_model->delete($where, 'tb_kategori');
        $this->session->set_flashdata('pesan', 'Kategori berhasil dihapus!');
        redirect('admin/kategori');
    }

    public function update($id)
    {
        $kode       = $_POST['kode'];
        $kategori   = $_POST['kategori'];

        $where = array('id' => $id);
        $dataKategori   = $this->m_model->get_where($where, 'tb_kategori');
        foreach ($dataKategori->result() as $dKtg) {
            if($kode == $dKtg->kode) {
                $data = array(
                    'kode' => $kode,
                    'kategori' => $kategori
                );
        
                $this->m_model->update($where, $data, 'tb_kategori');
                $this->session->set_flashdata('pesan', 'Kategori berhasil diubah!');
                redirect('admin/kategori');
            } else {
                $whereKode = array('kode' => $kode);
                $cek = $this->m_model->get_where($whereKode, 'tb_kategori');
                if(empty($cek->num_rows())) {
                    $data = array(
                        'kode' => $kode,
                        'kategori' => $kategori
                    );
            
                    $this->m_model->update($where, $data, 'tb_kategori');
                    $this->session->set_flashdata('pesan', 'Kategori berhasil diubah!');
                    redirect('admin/kategori');
                } else {
                    $this->session->set_flashdata('pesanError', 'Kategori sudah ada!');
                    redirect('admin/kategori');
                }
            }
        }
    }
}
