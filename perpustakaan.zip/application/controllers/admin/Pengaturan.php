<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pengaturan extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if(!$this->session->userdata('level')){
			$this->session->set_flashdata('pesan', 'Anda harus masuk terlebih dahulu!');
			redirect('home');
		}
	}

	public function index()
	{
        $data['title'] = 'Pengaturan';
        $data['pengaturan'] = $this->m_model->get_desc('tb_pengaturan');
		
		$this->load->view('admin/templates/header', $data);
		$this->load->view('admin/templates/sidebar');
		$this->load->view('admin/pengaturan');
		$this->load->view('admin/templates/footer');
    }
    
    public function update($id)
    {
        $nama   = $_POST['nama'];
        $telp   = $_POST['telp'];
        $email  = $_POST['email'];
        $alamat = $_POST['alamat'];
        $denda  = $_POST['denda'];
        $logo   = $_FILES['logo'];

        $where = array('id' => $id);

        if($logo != ''){
            $config['upload_path'] = './assets/gambar/';
            $config['allowed_types'] = 'png|jpg|jpeg';
            $config['file_name'] = 'Logo-' . time();
            $config['max_size'] = 5120;

            $this->load->library('upload', $config);

            if(!$this->upload->do_upload('logo')){
                $logo = '';
            } else {
                $logo = $this->upload->data('file_name');
            }
        }
        
        if($logo == ''){
            $data = array(
                'nama'      => $nama,
                'telp'      => $telp,
                'email'     => $email,
                'alamat'    => $alamat,
                'denda'     => $denda,
            );
        } else {
            $data = array(
                'nama'      => $nama,
                'telp'      => $telp,
                'email'     => $email,
                'alamat'    => $alamat,
                'denda'     => $denda,
                'logo'      => $logo,
            );
        }

        $this->m_model->update($where, $data, 'tb_pengaturan');
        $this->session->set_flashdata('pesan', 'Pengaturan berhasil diubah!');
        redirect('admin/pengaturan');
    }

    public function deletelogo($id)
    {
        $where = array('id' => $id);

        $data = array('logo' => '');
        $this->m_model->update($where, $data, 'tb_pengaturan');
        $this->session->set_flashdata('pesan', 'Pengaturan berhasil diubah!');
        redirect('admin/pengaturan');
    }
}
