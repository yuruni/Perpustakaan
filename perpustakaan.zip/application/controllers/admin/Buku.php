<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Buku extends CI_Controller {

	public function __construct()
	{
		parent::__construct();
		if(!$this->session->userdata('level')){
			$this->session->set_flashdata('pesan', 'Anda harus masuk terlebih dahulu!');
			redirect('home');
		}
	}

	public function index()
	{
        $data['title']  = 'Data Buku';
        $data['buku']   = $this->m_model->get_desc('tb_buku');
		
		$this->load->view('admin/templates/header', $data);
		$this->load->view('admin/templates/sidebar');
		$this->load->view('admin/buku');
		$this->load->view('admin/templates/footer');
	}

	public function add()
	{
		$data['title']  	= 'Tambah Data Buku';
		$data['kategori'] 	= $this->m_model->get_desc('tb_kategori');
		$data['rak'] 		= $this->m_model->get_desc('tb_rak');
		
		$this->load->view('admin/templates/header', $data);
		$this->load->view('admin/templates/sidebar');
		$this->load->view('admin/addbuku');
		$this->load->view('admin/templates/footer');
	}

	public function delete()
	{
		foreach ($_POST['id'] as $id) {
			$where = array('id' => $id);
			$this->m_model->delete($where, 'tb_buku');
		}

		$this->session->set_flashdata('pesan', 'Buku berhasil dihapus!');
		redirect('admin/buku');
		
	}

	public function insert()
	{
		date_default_timezone_set('Asia/Jakarta');
		$idKategori 	= $_POST['idKategori'];
		$idRak 			= $_POST['idRak'];
		$judul 			= $_POST['judul'];
		$edisi 			= $_POST['edisi'];
		$jilid 			= $_POST['jilid'];
		$penerbit 		= $_POST['penerbit'];
		$kota 			= $_POST['kota'];
		$tahunTerbit	= $_POST['tahunTerbit'];
		$isbn 			= $_POST['isbn'];
		$stok 			= $_POST['stok'];
		$pengarangSatu 	= $_POST['pengarangSatu'];
		$pengarangDua 	= $_POST['pengarangDua'];
		$no 			= $_POST['no'];
		$cover			= $_FILES['cover'];

		if($cover != ''){
            $config['upload_path'] 		= './assets/gambar/';
            $config['allowed_types'] 	= 'png|jpg|jpeg';
            $config['file_name'] 		= 'Cover-' . time();
            $config['max_size'] 		= 5120;

            $this->load->library('upload', $config);

            if(!$this->upload->do_upload('cover')){
                $cover = '';
            } else {
                $cover = $this->upload->data('file_name');
            }
        }

		$data = array(
			'idKategori' 	=> $idKategori,
			'idRak' 		=> $idRak,
			'no' 			=> $no,
			'judul' 		=> $judul,
			'edisi' 		=> $edisi,
			'jilid' 		=> $jilid,
			'penerbit' 		=> $penerbit,
			'kota' 			=> $kota,
			'tahunTerbit' 	=> $tahunTerbit,
			'isbn' 			=> $isbn,
			'stok' 			=> $stok,
			'pengarangSatu' => $pengarangSatu,
			'pengarangDua' 	=> $pengarangDua,
			'cover' 		=> $cover,
		);

		$where = array('no' => $no);
        $cek = $this->m_model->get_where($where, 'tb_buku');
        if(empty($cek->num_rows())) {
            $this->m_model->insert($data, 'tb_buku');
			$this->session->set_flashdata('pesan', 'Buku berhasil ditambahkan!');
			redirect('admin/buku');
        } else {
            $this->session->set_flashdata('pesanError', 'Kode buku sudah ada!');
            redirect('admin/buku');
        }
	}

	public function edit($id)
	{
		$data['title']  	= 'Edit Data Buku';
		$data['kategori'] 	= $this->m_model->get_desc('tb_kategori');
		$data['rak'] 		= $this->m_model->get_desc('tb_rak');

		$where = array('id' => $id);
		$data['edit'] = $this->m_model->get_where($where, 'tb_buku');
		
		$this->load->view('admin/templates/header', $data);
		$this->load->view('admin/templates/sidebar');
		$this->load->view('admin/editbuku');
		$this->load->view('admin/templates/footer');
	}

	public function update($id)
	{
		$idKategori 	= $_POST['idKategori'];
		$idRak 			= $_POST['idRak'];
		$judul 			= $_POST['judul'];
		$edisi 			= $_POST['edisi'];
		$jilid 			= $_POST['jilid'];
		$penerbit 		= $_POST['penerbit'];
		$kota 			= $_POST['kota'];
		$tahunTerbit	= $_POST['tahunTerbit'];
		$isbn 			= $_POST['isbn'];
		$stok 			= $_POST['stok'];
		$pengarangSatu 	= $_POST['pengarangSatu'];
		$pengarangDua 	= $_POST['pengarangDua'];

		$where = array('id' => $id);

		$data = array(
			'idRak' 		=> $idRak,
			'idKategori' 	=> $idKategori,
			'judul' 		=> $judul,
			'edisi' 		=> $edisi,
			'jilid' 		=> $jilid,
			'penerbit' 		=> $penerbit,
			'kota' 			=> $kota,
			'tahunTerbit' 	=> $tahunTerbit,
			'isbn' 			=> $isbn,
			'stok' 			=> $stok,
			'pengarangSatu' => $pengarangSatu,
			'pengarangDua' => $pengarangDua,
		);

		$this->m_model->update($where, $data, 'tb_buku');
		$this->session->set_flashdata('pesan', 'Buku berhasil diubah!');
		redirect('admin/buku');
	}

	public function exportsemua()
    {
        $data['buku'] = $this->m_model->get_desc('tb_buku');

        $this->load->view('admin/exportbuku', $data);
    }

	public function cetaksemua()
    {
        $data['buku'] = $this->m_model->get_desc('tb_buku');

        $this->load->view('admin/cetakbuku', $data);
    }
}
