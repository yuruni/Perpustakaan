<!DOCTYPE html>
<html lang="en">
  <head>    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Cetak Laporan Peminjaman Buku</title>

    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    <div class="container">
        <center><h3><b>Laporan Peminjaman Buku</b></h3></center>
        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>No Anggota</th>
                    <th>Nama Lengkap</th>
                    <th>Telp</th>
                    <th>Kode Buku</th>
                    <th>Judul Buku</th>
                    <th>Jumlah</th>
                    <th>Tgl Pinjam</th>
                    <th>Tgl Kembali</th>
                    <th>Tgl Pengembalian</th>
                    <th>Denda</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($peminjaman->result_array() as $row) { ?>
                    <tr>
                        <?php
                            $this->db->where('id', $row['idAnggota']);
                            $anggota = $this->db->get('tb_anggota');
                            foreach ($anggota->result_array() as $agt) { }
                        ?>
                            <td><?= $agt['no'] ?></td>
                            <td><?= $agt['nama'] ?></td>
                            <td><?= $agt['telp'] ?></td>
                        <?php
                            $this->db->where('id', $row['idBuku']);
                            $buku = $this->db->get('tb_buku');
                            foreach ($buku->result_array() as $bk) { }
                        ?>
                            <td><?= $bk['no'] ?></td>
                            <td><?= $bk['judul'] ?></td>
                        <td><?= $row['jml'] ?></td>
                        <td><?= date('d M Y', strtotime($row['tglPinjam'])) ?></td>
                        <td><?= date('d M Y', strtotime($row['tglKembali'])) ?></td>
                        <td>
                            <?php if ($row['tglPengembalian'] == '0000-00-00') { ?>
                                Belum Dikembalikan
                            <?php } else {
                                echo date('d M Y', strtotime($row['tglPengembalian']));
                            } ?>
                        </td>
                        <td>
                            <?php
                                if($row['tglPengembalian'] == '0000-00-00'){
                                    if (date('Y-m-d') > $row['tglKembali']) {
                                        $now = date('Y-m-d');
                                        $tgl = $row['tglKembali'];
                                        $hari = abs((strtotime($now) - strtotime($tgl)) / (60*60*24));
                                        $denda = $this->db->query('SELECT denda FROM tb_pengaturan');
                                        foreach ($denda->result() as $dnd) {}
                                        echo 'Rp. ' . number_format($hari * $dnd->denda, 0,',','.');
                                    } else {
                                        echo 'Rp. ' . number_format($row['denda'], 0,',','.');
                                    }
                                } else {
                                    echo 'Rp. ' . number_format($row['denda'], 0,',','.');
                                }
                            ?>
                        </td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
    </div>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <script>
        window.print();
    </script>
  </body>
</html>