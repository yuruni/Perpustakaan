<!DOCTYPE html>
<html lang="en">
  <head>    
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <title>Cetak Buku Belum Kembali</title>

    <!-- Bootstrap -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

    <!-- HTML5 shim and Respond.js for IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
      <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
      <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body>
    <div class="container">
        <center><h3><b>Laporan Data Buku Perpustakaan</b></h3></center>

        <table class="table table-bordered table-striped">
            <thead>
                <tr>
                    <th>Jml Pinjam</th>
                    <th>Rak</th>
                    <th>Kategori Buku</th>
                    <th>Kode Buku</th>
                    <th>Judul Buku</th>
                    <th>Edisi</th>
                    <th>Jilid</th>
                    <th>Penerbit</th>
                    <th>Kota</th>
                    <th>Tahun Terbit</th>
                    <th>ISBN</th>
                    <th>Stok</th>
                    <th>Pengarang 1</th>
                    <th>Pengarang 2</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($buku->result_array() as $row) { ?>
                    <tr>
                        <td>
                            <?php
                                $this->db->where('idBuku', $row['id']);
                                echo $this->db->get('tb_peminjaman')->num_rows();
                            ?>
                        </td>
                        <td>
                            <?php
                                $this->db->where('id', $row['idRak']);
                                $rak = $this->db->get('tb_rak');
                                foreach ($rak->result() as $rk) {
                                    echo $rk->rak;
                                }
                            ?>
                        </td>
                        <td>
                            <?php
                                $this->db->where('id', $row['idKategori']);
                                $kategori = $this->db->get('tb_kategori');
                                foreach ($kategori->result() as $ktg) {
                                    echo $ktg->kode . "-" . $ktg->kategori;
                                }
                            ?>
                        </td>
                        <td><?= $row['no']; ?></td>
                        <td><?= $row['judul']; ?></td>
                        <td><?= $row['edisi']; ?></td>
                        <td><?= $row['jilid']; ?></td>
                        <td><?= $row['penerbit']; ?></td>
                        <td><?= $row['kota']; ?></td>
                        <td><?= $row['tahunTerbit']; ?></td>
                        <td><?= $row['isbn']; ?></td>
                        <td><?= $row['stok']; ?></td>
                        <td><?= $row['pengarangSatu']; ?></td>
                        <td><?= $row['pengarangDua']; ?></td>
                    </tr>
                <?php } ?>
            </tbody>
        </table>
        
    </div>

    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    <script>
        window.print();
    </script>
  </body>
</html>