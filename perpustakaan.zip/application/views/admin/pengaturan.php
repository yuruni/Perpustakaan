<div class="content-wrapper">
    <section class="content-header">
        <h1>
            Pengaturan
            <small>Pengaturan umum aplikasi</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?= base_url('index.php/admin/dashboard') ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Pengaturan</li>
        </ol>
    </section>
    <section class="content">
        <?php foreach ($pengaturan->result_array() as $row) {} ?>
        <div class="box">
            <form class="form-horizontal" action="<?= base_url('index.php/admin/pengaturan/update/').$row['id'] ?>" method="POST" enctype="multipart/form-data">
              <div class="box-body">
                <div class="form-group">
                  <label class="col-sm-2 control-label">Nama Perpustakaan</label>

                  <div class="col-sm-10">
                    <input type="text" name="nama" class="form-control" value="<?= $row['nama']; ?>" placeholder="Nama Perpustakaan" required>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 control-label">Telephone</label>

                  <div class="col-sm-10">
                    <input type="number" name="telp" class="form-control" value="<?= $row['telp']; ?>" placeholder="Telephone" required>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 control-label">Email</label>

                  <div class="col-sm-10">
                    <input type="email" name="email" class="form-control" value="<?= $row['email']; ?>" placeholder="Email" required>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 control-label">Alamat</label>

                  <div class="col-sm-10">
                    <textarea name="alamat" class="form-control" placeholder="Alamat" required><?= $row['alamat'] ?></textarea>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 control-label">Denda Per Hari</label>

                  <div class="col-sm-10">
                    <input type="number" name="denda" class="form-control" value="<?= $row['denda']; ?>" placeholder="Denda" required>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 control-label">Logo <font color="red"><small>*)</small></font></label>

                  <div class="col-sm-10">
                    <input type="file" name="logo" class="form-control-file">
                    <?php if($row['logo'] != '') { ?>
                      <br>
                      <img src="<?= base_url('assets/gambar/').$row['logo'] ?>" alt="Logo" class="img-responsive" width="300px">
                      <br>
                      <a href="<?= base_url('index.php/admin/pengaturan/deletelogo/').$row['id'] ?>" class="btn btn-danger btn-sm tombol-yakin" data-isidata="Ingin menghapus logo?"><div class="fa fa-trash fa-sm"></div> Delete</a>
                    <?php } ?>
                  </div>
                </div>
              </div>
              <div class="box-footer">
                <small><b><font color="red">*) Tidak wajid diisi (Logo yang bisa diupload hanya berformat PNG, JPG dan JPEG dengan ukuran maksimal 5MB)</font></b></small>
                <button type="submit" class="btn btn-primary pull-right">
                    <div class="fa fa-save"></div> Save
                </button>
              </div>
            </form>
        </div>
    </section>
</div>