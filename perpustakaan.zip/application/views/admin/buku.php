<div class="content-wrapper">
    <section class="content-header">
        <h1>
            Data Buku
            <small>Daftar ketersediaan buku perpustakaan</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?= base_url('index.php/admin/dashboard') ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Data Buku</li>
        </ol>
    </section>
    <section class="content">
        <div class="box">
            <?php if($this->session->userdata('level') == 'Administrator') { ?>
                <div class="box-header">
                    <a href="<?= base_url('index.php/admin/buku/add') ?>" class="btn btn-primary">
                        <div class="fa fa-plus"></div> Tambah Data
                    </a>
                    <a href="<?= base_url('index.php/admin/buku/cetaksemua') ?>" class="btn btn-warning" target="blank">
                        <div class="fa fa-print"></div> Print
                    </a>
                    <a href="<?= base_url('index.php/admin/buku/exportsemua') ?>" class="btn btn-success" target="blank">
                        <div class="fa fa-file-excel-o"></div> Export Data
                    </a>
                </div>
            <?php } ?>
            <form action="<?= base_url('index.php/admin/buku/delete') ?>" method="POST">
                <div class="box-body">
                    <div class="table-responsive">
                        <table class="table table-bordered table-striped table-hover" id="dataTable">
                            <thead>
                                <tr>
                                    <?php if($this->session->userdata('level') == 'Administrator') { ?>
                                        <th width="10px">#</th>
                                    <?php } ?>
                                    <th width="50px">Cover</th>
                                    <th>Jml Pinjam</th>
                                    <th>Rak Buku</th>
                                    <th>Kategori Buku</th>
                                    <th>Kode Buku</th>
                                    <th>Judul Buku</th>
                                    <th>Edisi</th>
                                    <th>Jilid</th>
                                    <th>Penerbit</th>
                                    <th>Kota</th>
                                    <th>Tahun Terbit</th>
                                    <th>ISBN</th>
                                    <th>Stok</th>
                                    <th>Pengarang 1</th>
                                    <th>Pengarang 2</th>

                                    <?php if($this->session->userdata('level') == 'Administrator') { ?>
                                        <th>Aksi</th>
                                    <?php } ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    foreach ($buku->result_array() as $row) {
                                ?>
                                    <tr>
                                        <?php if($this->session->userdata('level') == 'Administrator') { ?>
                                            <td><input type="checkbox" name="id[]" value="<?= $row['id'] ?>"></td>
                                        <?php } ?>
                                        <td><img src="<?= base_url('assets/gambar/').$row['cover'] ?>" class="img-responsive"></td>
                                        <td>
                                            <?php
                                                $this->db->where('idBuku', $row['id']);
                                                echo $this->db->get('tb_peminjaman')->num_rows() . ' Peminjaman';
                                            ?>
                                        </td>
                                        <td>
                                            <?php
                                                $this->db->where('id', $row['idRak']);
                                                $rak = $this->db->get('tb_rak');
                                                foreach ($rak->result() as $rk) {
                                                    echo $rk->rak;
                                                }
                                            ?>
                                        </td>
                                        <td>
                                            <?php
                                                $this->db->where('id', $row['idKategori']);
                                                $kategori = $this->db->get('tb_kategori');
                                                foreach ($kategori->result() as $ktg) {
                                                    echo $ktg->kode . "-" . $ktg->kategori;
                                                }
                                            ?>
                                        </td>
                                        <td><?= $row['no']; ?></td>
                                        <td><?= $row['judul']; ?></td>
                                        <td><?= $row['edisi']; ?></td>
                                        <td><?= $row['jilid']; ?></td>
                                        <td><?= $row['penerbit']; ?></td>
                                        <td><?= $row['kota']; ?></td>
                                        <td><?= $row['tahunTerbit']; ?></td>
                                        <td><?= $row['isbn']; ?></td>
                                        <td><?= $row['stok']; ?></td>
                                        <td><?= $row['pengarangSatu']; ?></td>
                                        <td><?= $row['pengarangDua']; ?></td>

                                        <?php if($this->session->userdata('level') == 'Administrator') { ?>
                                            <td>
                                                <a href="<?= base_url('index.php/admin/buku/edit/').$row['id'] ?>" class="btn btn-warning btn-xs">
                                                    <div class="fa fa-edit fa-sm"></div> Edit
                                                </a>
                                            </td>
                                        <?php } ?>
                                    </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <?php if($this->session->userdata('level') == 'Administrator') { ?>
                    <div class="box-footer">
                        <button type="submit" class="btn btn-danger btn-xs" onclick="return confirm('Apakah anda yakin? akan perpengaruh pada data yang lain')">
                            <div class="fa fa-trash"></div> Delete
                        </button>
                    </div>
                <?php } ?>
            </form>
        </div>
    </section>
</div>