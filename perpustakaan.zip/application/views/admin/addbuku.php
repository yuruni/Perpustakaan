<div class="content-wrapper">
    <section class="content-header">
        <h1>
            Tambah Data Buku
            <small>Tambah buku perpustakaan</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?= base_url('index.php/admin/dashboard') ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="<?= base_url('index.php/admin/buku') ?>"> Data Buku</a></li>
            <li class="active">Tambah Buku</li>
        </ol>
    </section>
    <section class="content">
        <div class="box">
            <div class="box-header">
                <div class="box-title">Form Tambah Buku</div>
                <a href="<?= base_url('index.php/admin/buku') ?>" class="btn btn-primary btn-sm tombol-yakin pull-right" data-isidata="Ingin meninggalkan halaman ini?">
                    <div class="fa fa-arrow-left fa-sm"></div> Kembali
                </a>
            </div>
            <div class="box-body">
                <form action="<?= base_url('index.php/admin/buku/insert') ?>" method="POST" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Rak <font color='red'>*)</font></label>
                                <select name="idRak" class="form-control select2" required>
                                    <option value="" disabled selected> -- Pilih Rak -- </option>
                                    <?php foreach ($rak->result_array() as $rk) { ?>
                                        <option value="<?= $rk['id'] ?>"><?= $rk['rak'] ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Kategori <font color='red'>*)</font></label>
                                <select name="idKategori" class="form-control select2" required>
                                    <option value="" disabled selected> -- Pilih Kategori -- </option>
                                    <?php foreach ($kategori->result_array() as $row) { ?>
                                        <option value="<?= $row['id'] ?>"><?= $row['kode'] .' - '. $row['kategori'] ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Kode Buku <font color='red'>*)</font></label>
                        <input type="text" name="no" class="form-control" placeholder="Kode Buku" required>
                    </div>
                    <div class="form-group">
                        <label>Judul Buku <font color='red'>*)</font></label>
                        <input type="text" name="judul" class="form-control" placeholder="Judul Buku" required>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Edisi</label>
                                <input type="text" name="edisi" class="form-control" placeholder="Edisi">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Jilid</label>
                                <input type="text" name="jilid" class="form-control" placeholder="Jilid">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Penerbit</label>
                                <input type="text" name="penerbit" class="form-control" placeholder="Penerbit">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Kota</label>
                                <input type="text" name="kota" class="form-control" placeholder="Kota">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Tahun Terbit</label>
                                <input type="number" name="tahunTerbit" class="form-control" placeholder="Tahun Terbit">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>ISBN</label>
                                <input type="text" name="isbn" class="form-control" placeholder="ISBN">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Stok <font color="red">*)</font></label>
                                <input type="number" name="stok" class="form-control" placeholder="Stok" required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Pengarang 1</label>
                                <input type="text" name="pengarangSatu" class="form-control" placeholder="Pengarang 1">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Pengarang 2</label>
                                <input type="text" name="pengarangDua" class="form-control" placeholder="Pengarang 2">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Cover Buku <font color="red">*)</font></label>
                        <input type="file" name="cover" class="form-contron-file" required>
                    </div>
                    <p><small><font color="red"><b><i>*) Wajib diisi!</i></b></font></small></p>
                    <div class="pull-right">
                        <button type="reset" class="btn btn-danger">
                            <div class="fa fa-trash"></div> Reset
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <div class="fa fa-save"></div> Save
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </section>
</div>