<div class="content-wrapper">
    <section class="content-header">
        <h1>
            Edit Data Buku
            <small>Edit buku perpustakaan</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?= base_url('index.php/admin/dashboard') ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="<?= base_url('index.php/admin/buku') ?>"> Data Buku</a></li>
            <li class="active">Edit Buku</li>
        </ol>
    </section>
    <section class="content">
        <div class="box">
            <div class="box-header">
                <div class="box-title">Form Edit Buku</div>
                <a href="<?= base_url('index.php/admin/buku') ?>" class="btn btn-primary btn-sm tombol-yakin pull-right" data-isidata="Ingin meninggalkan halaman ini?">
                    <div class="fa fa-arrow-left fa-sm"></div> Kembali
                </a>
            </div>
            <?php foreach ($edit->result_array() as $dt) { } ?>
            <div class="box-body">
                <form action="<?= base_url('index.php/admin/buku/update/').$dt['id'] ?>" method="POST">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Rak <font color='red'>*)</font></label>
                                <select name="idRak" class="form-control select2" required>
                                    <option value="<?= $dt['idRak'] ?>" selected>
                                        <?php
                                            $this->db->where('id', $dt['idRak']);
                                            $whereRak = $this->db->get('tb_rak');
                                            foreach ($whereRak->result() as $wRk) {
                                                echo $wRk->rak;
                                            }
                                        ?>
                                    </option>
                                    <option value="" disabled> -- Pilih Rak Lain -- </option>
                                    <?php foreach ($rak->result_array() as $dk) { ?>
                                        <option value="<?= $dk['id'] ?>"><?= $dk['rak']?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Kategori <font color='red'>*)</font></label>
                                <select name="idKategori" class="form-control select2" required>
                                    <option value="<?= $dt['idKategori'] ?>" selected>
                                        <?php
                                            $this->db->where('id', $dt['idKategori']);
                                            $whereKategori = $this->db->get('tb_kategori');
                                            foreach ($whereKategori->result() as $wKtg) {
                                                echo $wKtg->kode . ' - ' . $wKtg->kategori;
                                            }
                                        ?>
                                    </option>
                                    <option value="" disabled> -- Pilih Kategori Lain -- </option>
                                    <?php foreach ($kategori->result_array() as $row) { ?>
                                        <option value="<?= $row['id'] ?>"><?= $row['kode'] .' - '. $row['kategori'] ?></option>
                                    <?php } ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <label>Judul Buku <font color='red'>*)</font></label>
                        <input type="text" name="judul" class="form-control" value="<?= $dt['judul'] ?>" placeholder="Judul Buku" required>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Edisi</label>
                                <input type="text" name="edisi" class="form-control" value="<?= $dt['edisi'] ?>" placeholder="Edisi">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Jilid</label>
                                <input type="text" name="jilid" class="form-control" value="<?= $dt['jilid'] ?>" placeholder="Jilid">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Penerbit</label>
                                <input type="text" name="penerbit" class="form-control" value="<?= $dt['penerbit'] ?>" placeholder="Penerbit">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Kota</label>
                                <input type="text" name="kota" class="form-control" value="<?= $dt['kota'] ?>" placeholder="Kota">
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Tahun Terbit</label>
                                <input type="number" name="tahunTerbit" class="form-control" value="<?= $dt['tahunTerbit'] ?>" placeholder="Tahun Terbit">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>ISBN</label>
                                <input type="text" name="isbn" class="form-control" value="<?= $dt['isbn'] ?>" placeholder="ISBN">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Stok <font color="red">*)</font></label>
                                <input type="number" name="stok" class="form-control" value="<?= $dt['stok'] ?>" placeholder="Stok" required>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Pengarang 1</label>
                                <input type="text" name="pengarangSatu" class="form-control" value="<?= $dt['pengarangSatu'] ?>" placeholder="Pengarang 1">
                            </div>
                        </div>
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Pengarang 2</label>
                                <input type="text" name="pengarangDua" class="form-control" value="<?= $dt['pengarangDua'] ?>" placeholder="Pengarang 2">
                            </div>
                        </div>
                    </div>
                    <p><small><font color="red"><b><i>*) Wajib diisi!</i></b></font></small></p>
                    <div class="pull-right">
                        <button type="reset" class="btn btn-danger">
                            <div class="fa fa-trash"></div> Reset
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <div class="fa fa-save"></div> Update
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </section>
</div>