<div class="content-wrapper">
    <section class="content-header">
        <h1>
            Tambah Data
            <small>Buku perpustakaan</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?= base_url('index.php/admin/dashboard') ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="<?= base_url('index.php/admin/peminjaman') ?>"> Data Peminjaman</a></li>
            <li class="active">Tambah Data</li>
        </ol>
    </section>
    <section class="content">
        <div class="box">
            <div class="box-header">
                <div class="box-title">Form Tambah Peminjaman</div>
                <a href="<?= base_url('index.php/admin/peminjaman') ?>" class="btn btn-primary btn-sm pull-right tombol-yakin" data-isidata="Ingin meninggalkan halaman ini?">
                    <div class="fa fa-arrow-left"></div> Kembali
                </a>
            </div>
            <div class="box-body">
                <form action="<?= base_url('index.php/admin/peminjaman/insert') ?>" method="POST">
                    <div class="form-group">
                        <label>Anggota</label>
                        <select name="idAnggota" class="form-control select2" required>
                            <option value="" disabled selected> -- Pilih Anggota -- </option>
                            <?php foreach ($anggota->result_array() as $agt) { ?>
                                <option value="<?= $agt['id'] ?>"><?= $agt['no'] . ' - ' . $agt['nama'] ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>Buku</label>
                        <select name="idBuku" class="form-control select2" required>
                            <option value="" disabled selected> -- Pilih Buku -- </option>
                            <?php foreach ($buku->result_array() as $bk) { ?>
                                <option value="<?= $bk['id'] ?>"><?= $bk['no'] . ' - ' . $bk['judul'] . ' - ' . $bk['stok'] ?></option>
                            <?php } ?>
                        </select>
                    </div>
                    <div class="row">
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Jumlah</label>
                                <input type="number" name="jml" class="form-control" placeholder="Jumlah" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Tgl Pinjam</label>
                                <input type="date" name="tglPinjam" class="form-control" value="<?= date('Y-m-d') ?>" required>
                            </div>
                        </div>
                        <div class="col-md-4">
                            <div class="form-group">
                                <label>Tgl Kembali</label>
                                <input type="date" name="tglKembali" class="form-control" value="<?= date('Y-m-d', strtotime('+14 days')) ?>" required>
                            </div>
                        </div>
                    </div>
                    <div class="pull-right">
                        <button type="reset" class="btn btn-danger">
                            <div class="fa fa-trash"></div> Reset
                        </button>
                        <button type="submit" class="btn btn-primary">
                            <div class="fa fa-save"></div> Save
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </section>
</div>