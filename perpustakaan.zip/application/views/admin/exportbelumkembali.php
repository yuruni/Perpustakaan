<?php
    header("Content-type: application/vnd-ms-excel");
    header("Content-Disposition: attachment; filename=Laporan Peminjaman Buku.xls");
?>
<table>
    <thead>
        <tr>
            <th colspan="10"><center>Laporan Peminjaman Buku</center></th>
        </tr>
        <tr>
            <th>No Anggota</th>
            <th>Nama Lengkap</th>
            <th>Telp</th>
            <th>Kode Buku</th>
            <th>Judul Buku</th>
            <th>Jumlah</th>
            <th>Tgl Pinjam</th>
            <th>Tgl Kembali</th>
            <th>Tgl Pengembalian</th>
            <th>Denda</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($peminjaman->result_array() as $row) { ?>
            <tr>
                <?php
                    $this->db->where('id', $row['idAnggota']);
                    $anggota = $this->db->get('tb_anggota');
                    foreach ($anggota->result_array() as $agt) { }
                ?>
                    <td><?= $agt['no'] ?></td>
                    <td><?= $agt['nama'] ?></td>
                    <td><?= $agt['telp'] ?></td>
                <?php
                    $this->db->where('id', $row['idBuku']);
                    $buku = $this->db->get('tb_buku');
                    foreach ($buku->result_array() as $bk) { }
                ?>
                    <td><?= $bk['no'] ?></td>
                    <td><?= $bk['judul'] ?></td>
                <td><?= $row['jml'] ?></td>
                <td><?= date('d M Y', strtotime($row['tglPinjam'])) ?></td>
                <td><?= date('d M Y', strtotime($row['tglKembali'])) ?></td>
                <td>
                    <?php if ($row['tglPengembalian'] == '0000-00-00') { ?>
                        Belum Dikembalikan
                    <?php } else {
                        echo date('d M Y', strtotime($row['tglPengembalian']));
                    } ?>
                </td>
                <td>
                    <?php
                        if($row['tglPengembalian'] == '0000-00-00'){
                            if (date('Y-m-d') > $row['tglKembali']) {
                                $now = date('Y-m-d');
                                $tgl = $row['tglKembali'];
                                $hari = abs((strtotime($now) - strtotime($tgl)) / (60*60*24));
                                $denda = $this->db->query('SELECT denda FROM tb_pengaturan');
                                foreach ($denda->result() as $dnd) {}
                                echo 'Rp. ' . number_format($hari * $dnd->denda, 0,',','.');
                            } else {
                                echo 'Rp. ' . number_format($row['denda'], 0,',','.');
                            }
                        } else {
                            echo 'Rp. ' . number_format($row['denda'], 0,',','.');
                        }
                    ?>
                </td>
            </tr>
        <?php } ?>
    </tbody>
</table>