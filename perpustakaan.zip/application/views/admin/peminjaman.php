<div class="content-wrapper">
    <section class="content-header">
        <h1>
            Data Peminjaman
            <small>Data peminjaman buku perpustakaan</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?= base_url('index.php/admin/dashboard') ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Data Peminjaman</li>
        </ol>
    </section>
    <section class="content">
        <div class="box">
            <div class="box-header">
                <a href="<?= base_url('index.php/admin/peminjaman/add') ?>" class="btn btn-primary">
                    <div class="fa fa-plus"></div> Tambah Data
                </a>
                <a href="<?= base_url('index.php/admin/peminjaman/cetakbelumkembali') ?>" class="btn btn-warning">
                    <div class="fa fa-print"></div> Print
                </a>
                <a href="<?= base_url('index.php/admin/peminjaman/exportbelumkembali') ?>" class="btn btn-success">
                    <div class="fa fa-file-excel-o"></div> Export Data
                </a>
            </div>
            <div class="box-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover" id="dataTable">
                        <thead>
                            <tr>
                                <th width="10px">#</th>
                                <th>No Anggota</th>
                                <th>Nama Lengkap</th>
                                <th>Telp</th>
                                <th>Kode Buku</th>
                                <th>Judul Buku</th>
                                <th>Jumlah</th>
                                <th>Tgl Pinjam</th>
                                <th>Tgl Kembali</th>
                                <th>Tgl Pengembalian</th>
                                <th>Denda</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $no = 1;
                                foreach ($peminjaman->result_array() as $row) { ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <?php
                                        $this->db->where('id', $row['idAnggota']);
                                        $anggota = $this->db->get('tb_anggota');
                                        foreach ($anggota->result_array() as $agt) { }
                                    ?>
                                        <td><?= $agt['no'] ?></td>
                                        <td><?= $agt['nama'] ?></td>
                                        <td><?= $agt['telp'] ?></td>
                                    <?php
                                        $this->db->where('id', $row['idBuku']);
                                        $buku = $this->db->get('tb_buku');
                                        foreach ($buku->result_array() as $bk) { }
                                    ?>
                                        <td><?= $bk['no'] ?></td>
                                        <td><?= $bk['judul'] ?></td>
                                    <td><?= $row['jml'] ?></td>
                                    <td><?= date('d M Y', strtotime($row['tglPinjam'])) ?></td>
                                    <td><?= date('d M Y', strtotime($row['tglKembali'])) ?></td>
                                    <td>
                                        <?php if ($row['tglPengembalian'] == '0000-00-00') { ?>
                                            <div class="label label-danger"> Belum Dikembalikan</div>
                                        <?php } else {
                                            echo date('d M Y', strtotime($row['tglPengembalian']));
                                        } ?>
                                    </td>
                                    <td>
                                        <?php
                                            if($row['tglPengembalian'] == '0000-00-00'){
                                                if (date('Y-m-d') > $row['tglKembali']) {
                                                    $now = date('Y-m-d');
                                                    $tgl = $row['tglKembali'];
                                                    $hari = abs((strtotime($now) - strtotime($tgl)) / (60*60*24));
                                                    $denda = $this->db->query('SELECT denda FROM tb_pengaturan');
                                                    foreach ($denda->result() as $dnd) {}
                                                    echo 'Rp. ' . number_format($hari * $dnd->denda, 0,',','.');
                                                } else {
                                                    echo 'Rp. ' . number_format($row['denda'], 0,',','.');
                                                }
                                            } else {
                                                echo 'Rp. ' . number_format($row['denda'], 0,',','.');
                                            }
                                        ?>
                                    </td>
                                    <td>
                                        <?php if (date('Y-m-d') < $row['tglKembali'] AND $row['tglPengembalian'] == '0000-00-00') { ?>
                                            <a href="<?= base_url('index.php/admin/peminjaman/perpanjang/').$row['id'].'/'.$row['tglKembali'] ?>" data-toggle="tooltip" title="Perpanjang 7 Hari" class="btn btn-success btn-sm tombol-yakin" data-isidata="Apakah anda yakin ingin memperpanjang peminjaman ini?">
                                                <div class="fa fa-calendar"></div>
                                            </a>
                                        <?php } ?>
                                        <?php if($row['tglPengembalian'] == '0000-00-00') { ?>
                                            <a href="<?= base_url('index.php/admin/peminjaman/kembali/').$row['id'] ?>" data-toggle="tooltip" title="Kembalikan" class="btn btn-warning btn-sm tombol-yakin" data-isidata="Apakah anda yakin ingin mengambalikan peminjaman ini?">
                                                <div class="fa fa-refresh   "></div>
                                            </a>
                                        <?php } ?>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
</div>