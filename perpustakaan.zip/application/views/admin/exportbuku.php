<?php
    header("Content-type: application/vnd-ms-excel");
    header("Content-Disposition: attachment; filename=Laporan Data Buku Perpustakaan.xls");
?>
<table>
    <thead>
        <tr>
            <th colspan="13"><center>Laporan Data Buku Perpustakaan</center></th>
        </tr>
        <tr>
            <th>Jml Pinjam</th>
            <th>Rak</th>
            <th>Kategori Buku</th>
            <th>Kode Buku</th>
            <th>Judul Buku</th>
            <th>Edisi</th>
            <th>Jilid</th>
            <th>Penerbit</th>
            <th>Kota</th>
            <th>Tahun Terbit</th>
            <th>ISBN</th>
            <th>Stok</th>
            <th>Pengarang 1</th>
            <th>Pengarang 2</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($buku->result_array() as $row) { ?>
            <tr>
                <td>
                    <?php
                        $this->db->where('idBuku', $row['id']);
                        echo $this->db->get('tb_peminjaman')->num_rows();
                    ?>
                </td>
                <td>
                    <?php
                        $this->db->where('id', $row['idRak']);
                        $rak = $this->db->get('tb_rak');
                        foreach ($rak->result() as $rk) {
                            echo $rk->rak;
                        }
                    ?>
                </td>
                <td>
                    <?php
                        $this->db->where('id', $row['idKategori']);
                        $kategori = $this->db->get('tb_kategori');
                        foreach ($kategori->result() as $ktg) {
                            echo $ktg->kode . "-" . $ktg->kategori;
                        }
                    ?>
                </td>
                <td><?= $row['no']; ?></td>
                <td><?= $row['judul']; ?></td>
                <td><?= $row['edisi']; ?></td>
                <td><?= $row['jilid']; ?></td>
                <td><?= $row['penerbit']; ?></td>
                <td><?= $row['kota']; ?></td>
                <td><?= $row['tahunTerbit']; ?></td>
                <td><?= $row['isbn']; ?></td>
                <td><?= $row['stok']; ?></td>
                <td><?= $row['pengarangSatu']; ?></td>
                <td><?= $row['pengarangDua']; ?></td>
            </tr>
        <?php } ?>
    </tbody>
</table>