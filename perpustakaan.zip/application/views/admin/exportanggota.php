<?php
    header("Content-type: application/vnd-ms-excel");
    header("Content-Disposition: attachment; filename=Laporan Data Anggota Perpustakaan.xls");
?>
<table>
    <thead>
        <tr>
            <th colspan="7"><center>Laporan Data Anggota Perpustakaan</center></th>
        </tr>
        <tr>
            <th>Jml Pinjam</th>
            <th>Kode Anggota</th>
            <th>Nama Lengkap</th>
            <th>Jenis kelamin</th>
            <th>Tempat, Tanggal Lahir</th>
            <th>Alamat</th>
            <th>Telephone</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($anggota->result_array() as $row) { ?>
            <tr>
                <td>
                    <?php
                        $this->db->where('idAnggota', $row['id']);
                        echo $this->db->get('tb_peminjaman')->num_rows();
                    ?>
                </td>
                <td><?= $row['no'] ?></td>
                <td><?= $row['nama'] ?></td>
                <td><?= $row['jenisKelamin'] ?></td>
                <td><?= $row['tempatLahir'] . ', '. date('d M Y', strtotime($row['tanggalLahir'])) ?></td>
                <td><?= $row['alamat'] ?></td>
                <td><?= $row['telp'] ?></td>
            </tr>
        <?php } ?>
    </tbody>
</table>