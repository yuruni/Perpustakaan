<div class="content-wrapper">
    <section class="content-header">
        <h1>
            Data Rak
            <small>Semua data rak akan ditampilkan disini</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?= base_url('index.php/admin/dashboard') ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Data Rak</li>
        </ol>
    </section>
    <section class="content">
        <div class="box">
            <?php if($this->session->userdata('level') == 'Administrator') { ?>
                <div class="box-header">
                    <button class="btn btn-primary" data-toggle="modal" data-target="#tambahData"><div class="fa fa-plus"></div> Tambah Data</button>
                </div>
            <?php } ?>
            <div class="box-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped responsive display nowrap" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th width="10px">#</th>
                                <th>Nama Rak</th>
                                <th>Jumlah Buku</th>
                                <?php if($this->session->userdata('level') == 'Administrator') { ?>   
                                    <th>Aksi</th>
                                <?php } ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $no = 1;
                                foreach ($rak->result_array() as $row) { ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><?= $row['rak'] ?></td>
                                    <td>
                                        <?php
                                            $this->db->where('idRak', $row['id']);
                                            $jumlah = $this->db->get('tb_buku');
                                            echo $jumlah->num_rows();
                                        ?>
                                    </td>
                                    <?php if($this->session->userdata('level') == 'Administrator') { ?>   
                                        <td>
                                            <button class="btn btn-warning btn-xs" data-toggle="modal" data-target="#editData<?= $row['id'] ?>"><div class="fa fa-edit fa-sm"></div> Edit</button>
                                            <a href="<?= base_url('index.php/admin/rak/delete/').$row['id'] ?>" class="btn btn-danger btn-xs tombol-yakin" data-isidata="Akan berpengaruh pada data buku!"><div class="fa fa-trash fa-sm"></div> Hapus</a>
                                        </td>
                                    <?php } ?>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
</div>

<!-- Modal Tambah Data-->
<div class="modal fade" id="tambahData" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Tambah Rak Buku</h4>
      </div>
      <form action="<?= base_url('index.php/admin/rak/insert') ?>" method="POST">
        <div class="modal-body">
            <div class="form-group">
                <label>Nama Rak Buku</label>
                <input type="text" class="form-control" name="rak" placeholder="Nama Rak Buku" required>
            </div>
        </div>
        <div class="modal-footer">
            <button type="reset" class="btn btn-danger"><div class="fa fa-trash"></div> Reset</button>
            <button type="submit" class="btn btn-primary"><div class="fa fa-save"></div> Save</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal Edit Data -->
<?php foreach ($rak->result() as $eRk) { ?>
    <div class="modal fade" id="editData<?= $eRk->id ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title" id="myModalLabel">Edit Rak Buku</h4>
            </div>
            <form action="<?= base_url('index.php/admin/rak/update/').$eRk->id ?>" method="POST">
                <div class="modal-body">
                    <div class="form-group">
                        <label>Nama Rak Buku</label>
                        <input type="text" class="form-control" value="<?= $eRk->rak ?>" name="rak" placeholder="Nama Rak Buku" required>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="reset" class="btn btn-danger"><div class="fa fa-trash"></div> Reset</button>
                    <button type="submit" class="btn btn-primary"><div class="fa fa-save"></div> Update</button>
                </div>
            </form>
            </div>
        </div>
    </div>
<?php } ?>