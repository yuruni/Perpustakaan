<div class="content-wrapper">
    <section class="content-header">
        <h1>
            Anggota
            <small>Data Anggota Perpustakaan</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?= base_url('index.php/admin/dashboard') ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Data Anggota</li>
        </ol>
    </section>
    <section class="content">
        <div class="box">
            <div class="box-header">
                <button class="btn btn-primary" data-toggle="modal" data-target="#tambahData">
                    <div class="fa fa-plus"></div> Tambah Data
                </button>
                <a href="<?= base_url('index.php/admin/anggota/cetaksemua') ?>" class="btn btn-warning">
                    <div class="fa fa-print"></div> Print
                </a>
                <a href="<?= base_url('index.php/admin/anggota/exportsemua') ?>" class="btn btn-success">
                    <div class="fa fa-file-excel-o"></div> Export Data
                </a>
            </div>
            <div class="box-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped table-hover" id="dataTable">
                        <thead>
                            <tr>
                                <th width="10px">#</th>
                                <th>Jml Pinjam</th>
                                <th>Kode Anggota</th>
                                <th>Nama Lengkap</th>
                                <th>Jenis kelamin</th>
                                <th>Tempat, Tanggal Lahir</th>
                                <th>Alamat</th>
                                <th>Telephone</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $no = 1;
                                foreach ($anggota->result_array() as $row) { ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td>
                                        <?php
                                            $this->db->where('idAnggota', $row['id']);
                                            echo $this->db->get('tb_peminjaman')->num_rows() . ' Peminjaman';
                                        ?>
                                    </td>
                                    <td><?= $row['no'] ?></td>
                                    <td><?= $row['nama'] ?></td>
                                    <td><?= $row['jenisKelamin'] ?></td>
                                    <td><?= $row['tempatLahir'] . ', '. date('d M Y', strtotime($row['tanggalLahir'])) ?></td>
                                    <td><?= $row['alamat'] ?></td>
                                    <td><?= $row['telp'] ?></td>
                                    <td>
                                        <button class="btn btn-warning btn-sm" data-toggle="modal" data-target="#editData<?= $row['id'] ?>"><div class="fa fa-edit fa-sm"></div> Edit</button>
                                        <a href="<?= base_url('index.php/admin/anggota/delete/').$row['id'] ?>" class="btn btn-danger btn-sm tombol-yakin" data-isidata="Ingin menghapus anggota ini?"><div class="fa fa-trash fa-sm"></div> Hapus</a>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
</div>

<!-- Modal Tambah Data-->
<div class="modal fade" id="tambahData" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Tambah Anggota</h4>
      </div>
      <form action="<?= base_url('index.php/admin/anggota/insert') ?>" method="POST">
        <div class="modal-body">
            <div class="form-group">
                <label>Kode Anggota</label>
                <input type="text" class="form-control" name="no" placeholder="Kode Anggota" required>
            </div>
            <div class="form-group">
                <label>Nama Lengkap</label>
                <input type="text" class="form-control" name="nama" placeholder="Nama Lengkap" required>
            </div>
            <div class="form-group">
                <label>Jenis Kelamin</label>
                <select name="jenisKelamin" class="form-control" required>
                    <option value="" disabled selected> -- Pilih Jenis Kelamin -- </option>
                    <option value="Laki-Laki">Laki-Laki</option>
                    <option value="Perempuan">Perempuan</option>
                </select>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Tempat Lahir</label>
                        <input type="text" class="form-control" name="tempatLahir" placeholder="Tempat Lahir" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Tanggal Lahir</label>
                        <input type="date" class="form-control" name="tanggalLahir" required>
                    </div>   
                </div>
            </div>
            <div class="form-group">
                <label>Telphone</label>
                <input type="number" class="form-control" name="telp" placeholder="Telephone" required>
            </div>
            <div class="form-group">
                <label>Alamat</label>
                <textarea name="alamat" class="form-control" placeholder="Alamat" required></textarea>
            </div>
            <font color="red"><small><i><b>Nomor anggota akan dibuat otomatis ketika data disimpan</b></i></small></font>
        </div>
        <div class="modal-footer">
            <button type="reset" class="btn btn-danger"><div class="fa fa-trash"></div> Reset</button>
            <button type="submit" class="btn btn-primary"><div class="fa fa-save"></div> Save</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal Edit Data -->
<?php foreach ($anggota->result() as $row) { ?>
<div class="modal fade" id="editData<?= $row->id ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Edit Data Anggota</h4>
      </div>
      <form action="<?= base_url('index.php/admin/anggota/update/').$row->id ?>" method="POST">
        <div class="modal-body">
            <div class="form-group">
                <label>Kode Anggota</label>
                <input type="text" class="form-control" value="<?= $row->no; ?>" disabled required>
            </div>
            <div class="form-group">
                <label>Nama Lengkap</label>
                <input type="text" class="form-control" name="nama" value="<?= $row->nama; ?>" placeholder="Nama Lengkap" required>
            </div>
            <div class="form-group">
                <label>Jenis Kelamin</label>
                <select name="jenisKelamin" class="form-control" required>
                    <?php if ($row->jenisKelamin == 'Laki-Laki') { ?>
                        <option value="Laki-Laki" selected>Laki-Laki</option>
                        <option value="Perempuan">Perempuan</option>
                    <?php } else { ?>
                        <option value="Perempuan" selected>Perempuan</option>
                        <option value="Laki-Laki">Laki-Laki</option>
                    <?php } ?>
                </select>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Tempat Lahir</label>
                        <input type="text" class="form-control" name="tempatLahir" value="<?= $row->tempatLahir; ?>" placeholder="Tempat Lahir" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="form-group">
                        <label>Tanggal Lahir</label>
                        <input type="date" class="form-control" name="tanggalLahir" value="<?= $row->tanggalLahir; ?>" required>
                    </div>   
                </div>
            </div>
            <div class="form-group">
                <label>Telphone</label>
                <input type="number" class="form-control" name="telp" value="<?= $row->telp; ?>" placeholder="Telephone" required>
            </div>
            <div class="form-group">
                <label>Alamat</label>
                <textarea name="alamat" class="form-control" placeholder="Alamat" required><?= $row->alamat; ?></textarea>
            </div>
        </div>
        <div class="modal-footer">
            <button type="reset" class="btn btn-danger"><div class="fa fa-trash"></div> Reset</button>
            <button type="submit" class="btn btn-primary"><div class="fa fa-save"></div> Update</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php } ?>