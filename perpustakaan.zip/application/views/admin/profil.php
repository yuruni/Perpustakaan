<div class="content-wrapper">
    <section class="content-header">
        <h1>
            Profil
            <small>Data profil anda</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?= base_url('index.php/admin/dashboard') ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Profil</li>
        </ol>
    </section>
    <section class="content">
        <div class="box">
            <form class="form-horizontal" action="<?= base_url('index.php/admin/profil/update/').$this->session->userdata('id') ?>" method="POST">
              <div class="box-body">
                <div class="form-group">
                  <label class="col-sm-2 control-label">Nama Lengkap</label>

                  <div class="col-sm-10">
                    <input type="text" name="nama" class="form-control" value="<?= $this->session->userdata('nama'); ?>" placeholder="Nama Lengkap" required>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 control-label">Username</label>

                  <div class="col-sm-10">
                    <input type="text" name="username" class="form-control" value="<?= $this->session->userdata('username'); ?>" placeholder="Username" required>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 control-label">New Password <font color="red">*</font></label>

                  <div class="col-sm-10">
                    <input type="password" name="password" class="form-control" placeholder="New Password">
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 control-label">Skin</label>

                  <div class="col-sm-10">
                    <select name="skin" class="form-control" required>
                        <option value="<?= $this->session->userdata('skin') ?>" selected><?= $this->session->userdata('skin') ?></option>
                        <option value="" disabled> -- Pilih Skin Lain -- </option>
                        <option value="yellow">yellow</option>
                        <option value="red">red</option>
                        <option value="green">green</option>
                        <option value="purple">purple</option>
                        <option value="blue">blue</option>
                    </select>
                  </div>
                </div>
                <div class="form-group">
                  <label class="col-sm-2 control-label">Level</label>

                  <div class="col-sm-10">
                    <input type="text" class="form-control" value="<?= $this->session->userdata('level') ?>" disabled>
                  </div>
                </div>
              </div>
              <div class="box-footer">
              <small><b><i><font color="red">* Kosongkan jika tidak ingin diganti!</font></i></b></small>
                <button type="submit" class="btn btn-primary pull-right">
                    <div class="fa fa-save"></div> Save
                </button>
              </div>
            </form>
        </div>
    </section>
</div>