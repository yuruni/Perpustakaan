<div class="content-wrapper">
    <section class="content-header">
        <h1>
            Dashboard
            <small>Control Panel</small>
        </h1>
        <!-- <ol class="breadcrumb">
            <li><a href="#"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li><a href="#">Layout</a></li>
            <li class="active">Fixed</li>
        </ol> -->
    </section>
    <section class="content">
        <div class="row">
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="info-box">
                    <span class="info-box-icon bg-red"><i class="fa fa-columns"></i></span>

                    <div class="info-box-content">
                    <span class="info-box-text">TOTAL KATEGORI</span>
                    <span class="info-box-number">
                        <?php
                            $jumlahKategori = $this->db->query('SELECT id FROM tb_kategori');
                            echo $jumlahKategori->num_rows();
                        ?>
                    </span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="info-box">
                    <span class="info-box-icon bg-blue"><i class="fa fa-book"></i></span>

                    <div class="info-box-content">
                    <span class="info-box-text">TOTAL BUKU</span>
                    <span class="info-box-number">
                        <?php
                            $jumlahBuku = $this->db->query('SELECT id FROM tb_buku');
                            echo $jumlahBuku->num_rows();
                        ?>
                    </span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="info-box">
                    <span class="info-box-icon bg-green"><i class="fa fa-calendar"></i></span>

                    <div class="info-box-content">
                    <span class="info-box-text">BUKU BELUM KEMBALI</span>
                    <span class="info-box-number">
                        <?php
                            $bukuBelumKembali = $this->db->query('SELECT id FROM tb_peminjaman WHERE tglPengembalian="0000-00-00" ');
                            echo $bukuBelumKembali->num_rows();
                        ?>
                    </span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="info-box">
                    <span class="info-box-icon bg-yellow"><i class="fa fa-graduation-cap"></i></span>

                    <div class="info-box-content">
                    <span class="info-box-text">TOTAL ANGGOTA</span>
                    <span class="info-box-number">
                        <?php
                            $jumlahAnggota = $this->db->query('SELECT id FROM tb_anggota');
                            echo $jumlahAnggota->num_rows();
                        ?>
                    </span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="info-box">
                    <span class="info-box-icon bg-purple"><i class="fa fa-database"></i></span>

                    <div class="info-box-content">
                    <span class="info-box-text">TOTAL RAK</span>
                    <span class="info-box-number">
                        <?php
                            $rakBuku = $this->db->query('SELECT id FROM tb_rak');
                            echo $rakBuku->num_rows();
                        ?>
                    </span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="info-box">
                    <span class="info-box-icon bg-aqua"><i class="fa fa-users"></i></span>

                    <div class="info-box-content">
                    <span class="info-box-text">TOTAL Karyawan</span>
                    <span class="info-box-number">
                        <?php
                            $jumlahKaryawan = $this->db->query('SELECT id FROM tb_user WHERE level="Karyawan" ');
                            echo $jumlahKaryawan->num_rows();
                        ?>
                    </span>
                    </div>
                </div>
            </div>
            <div class="col-md-3 col-sm-6 col-xs-12">
                <div class="info-box">
                    <span class="info-box-icon bg-red"><i class="fa fa-user"></i></span>

                    <div class="info-box-content">
                    <span class="info-box-text">TOTAL ADMINISTRATOR</span>
                    <span class="info-box-number">
                        <?php
                            $jumlahAdmin = $this->db->query('SELECT id FROM tb_user WHERE level="Administrator" ');
                            echo $jumlahAdmin->num_rows();
                        ?>
                    </span>
                    </div>
                </div>
            </div>
        </div>
        <div class="box">
            <div class="box-header">
                <div class="box-title">Peminjaman Belum Kambali</div>
            </div>
            <div class="box-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover" id="dataTable">
                        <thead>
                            <tr>
                                <th width="10px">#</th>
                                <th>No Anggota</th>
                                <th>Nama Lengkap</th>
                                <th>Kode Buku</th>
                                <th>Judul Buku</th>
                                <th>Jumlah</th>
                                <th>Tgl Pinjam</th>
                                <th>Tgl Kembali</th>
                                <th>Tgl Pengembalian</th>
                                <th>Denda</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($peminjaman->result_array() as $row) { ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <?php
                                        $this->db->where('id', $row['idAnggota']);
                                        $anggota = $this->db->get('tb_anggota');
                                        foreach ($anggota->result_array() as $agt) { }
                                    ?>
                                        <td><?= $agt['no'] ?></td>
                                        <td><?= $agt['nama'] ?></td>
                                    <?php
                                        $this->db->where('id', $row['idBuku']);
                                        $buku = $this->db->get('tb_buku');
                                        foreach ($buku->result_array() as $bk) { }
                                    ?>
                                        <td><?= $bk['no'] ?></td>
                                        <td><?= $bk['judul'] ?></td>
                                    <td><?= $row['jml'] ?></td>
                                    <td><?= date('d M Y', strtotime($row['tglPinjam'])) ?></td>
                                    <td><?= date('d M Y', strtotime($row['tglKembali'])) ?></td>
                                    <td>
                                        <?php if ($row['tglPengembalian'] == '0000-00-00') { ?>
                                            <div class="label label-danger"> Belum Dikembalikan</div>
                                        <?php } else {
                                            echo date('d M Y', strtotime($row['tglPengembalian']));
                                        } ?>
                                    </td>
                                    <td>
                                        <?php
                                            if($row['tglPengembalian'] == '0000-00-00'){
                                                if (date('Y-m-d') > $row['tglKembali']) {
                                                    $now = date('Y-m-d');
                                                    $tgl = $row['tglKembali'];
                                                    $hari = abs((strtotime($now) - strtotime($tgl)) / (60*60*24));
                                                    $denda = $this->db->query('SELECT denda FROM tb_pengaturan');
                                                    foreach ($denda->result() as $dnd) {}
                                                    echo 'Rp. ' . number_format($hari * $dnd->denda, 0,',','.');
                                                } else {
                                                    echo 'Rp. ' . number_format($row['denda'], 0,',','.');
                                                }
                                            } else {
                                                echo 'Rp. ' . number_format($row['denda'], 0,',','.');
                                            }
                                        ?>
                                    </td>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
</div>