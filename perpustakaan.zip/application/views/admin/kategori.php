<div class="content-wrapper">
    <section class="content-header">
        <h1>
            Kategori
            <small>Kategori Buku</small>
        </h1>
        <ol class="breadcrumb">
            <li><a href="<?= base_url('index.php/admin/dashboard') ?>"><i class="fa fa-dashboard"></i> Dashboard</a></li>
            <li class="active">Data Kategori</li>
        </ol>
    </section>
    <section class="content">
        <div class="box">
            <?php if($this->session->userdata('level') == 'Administrator') { ?>
                <div class="box-header">
                    <button class="btn btn-primary" data-toggle="modal" data-target="#tambahData"><div class="fa fa-plus"></div> Tambah Data</button>
                </div>
            <?php } ?>
            <div class="box-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-striped responsive display nowrap" id="dataTable" width="100%" cellspacing="0">
                        <thead>
                            <tr>
                                <th width="10px">#</th>
                                <th>Kode Kategori</th>
                                <th>Kategori</th>
                                <th>Jumlah Buku</th>
                                <?php if($this->session->userdata('level') == 'Administrator') { ?>   
                                    <th>Aksi</th>
                                <?php } ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                                $no = 1;
                                foreach ($kategori->result_array() as $row) { ?>
                                <tr>
                                    <td><?= $no++ ?></td>
                                    <td><?= $row['kode'] ?></td>
                                    <td><?= $row['kategori'] ?></td>
                                    <td>
                                        <?php
                                            $this->db->where('idKategori', $row['id']);
                                            $jumlah = $this->db->get('tb_buku');
                                            echo $jumlah->num_rows();
                                        ?>
                                    </td>
                                    <?php if($this->session->userdata('level') == 'Administrator') { ?>   
                                        <td>
                                            <button class="btn btn-warning btn-xs" data-toggle="modal" data-target="#editData<?= $row['id'] ?>"><div class="fa fa-edit fa-sm"></div> Edit</button>
                                            <a href="<?= base_url('index.php/admin/kategori/delete/').$row['id'] ?>" class="btn btn-danger btn-xs tombol-yakin" data-isidata="Akan berpengaruh pada data buku!"><div class="fa fa-trash fa-sm"></div> Hapus</a>
                                        </td>
                                    <?php } ?>
                                </tr>
                            <?php } ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
</div>

<!-- Modal Tambah Data-->
<div class="modal fade" id="tambahData" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Tambah Kategori</h4>
      </div>
      <form action="<?= base_url('index.php/admin/kategori/insert') ?>" method="POST">
        <div class="modal-body">
            <div class="form-group">
                <label>Kode Kategori</label>
                <input type="text" class="form-control" name="kode" placeholder="Kode Kategori" required>
            </div>
            <div class="form-group">
                <label>Nama Kategori</label>
                <input type="text" class="form-control" name="kategori" placeholder="Nama Kategori" required>
            </div>
        </div>
        <div class="modal-footer">
            <button type="reset" class="btn btn-danger"><div class="fa fa-trash"></div> Reset</button>
            <button type="submit" class="btn btn-primary"><div class="fa fa-save"></div> Save</button>
        </div>
      </form>
    </div>
  </div>
</div>

<!-- Modal Edit Data -->
<?php foreach ($kategori->result() as $row) { ?>
<div class="modal fade" id="editData<?= $row->id ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="myModalLabel">Edit Kategori</h4>
      </div>
      <form action="<?= base_url('index.php/admin/kategori/update/').$row->id ?>" method="POST">
        <div class="modal-body">
            <div class="form-group">
                <label>Kode Kategori</label>
                <input type="text" class="form-control" name="kode" placeholder="Kode Kategori" value="<?= $row->kode; ?>" required>
            </div>
            <div class="form-group">
                <label>Nama Kategori</label>
                <input type="text" class="form-control" name="kategori" placeholder="Nama Kategori" value="<?= $row->kategori; ?>" required>
            </div>
        </div>
        <div class="modal-footer">
            <button type="reset" class="btn btn-danger"><div class="fa fa-trash"></div> Reset</button>
            <button type="submit" class="btn btn-primary"><div class="fa fa-save"></div> Update</button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php } ?>